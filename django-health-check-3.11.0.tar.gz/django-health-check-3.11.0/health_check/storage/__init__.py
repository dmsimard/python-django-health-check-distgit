default_app_config = 'health_check.storage.apps.HealthCheckConfig'
