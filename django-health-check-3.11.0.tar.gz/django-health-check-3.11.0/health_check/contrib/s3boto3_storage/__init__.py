default_app_config = 'health_check.contrib.s3boto3_storage.apps.HealthCheckConfig'
