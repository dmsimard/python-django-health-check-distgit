default_app_config = 'health_check.contrib.rabbitmq.apps.HealthCheckConfig'
