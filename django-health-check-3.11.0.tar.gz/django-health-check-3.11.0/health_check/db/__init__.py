default_app_config = 'health_check.db.apps.HealthCheckConfig'
