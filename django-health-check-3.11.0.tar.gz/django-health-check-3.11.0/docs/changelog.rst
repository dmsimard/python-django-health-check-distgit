ChangeLog
=========

This package is released on GitHub. Please refer to the GitHub
release page to review the changes in each version.

https://github.com/KristianOellegaard/django-health-check/releases
